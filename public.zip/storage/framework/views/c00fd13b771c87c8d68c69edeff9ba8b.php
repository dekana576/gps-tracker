<a href="/" style="display: flex; align-items: center; gap: 10px;">
    <img src="<?php echo e(asset('images/astra.png')); ?>" alt="logo astra" style="height: 40px;" class="w-auto">
    <img src="<?php echo e(asset('images/best.png')); ?>" alt="logo best" style="height: 40px;" class="w-auto">
</a>

<?php /**PATH D:\Kampus\PKL\Astra Honda\project\gps-tracker-laravel\resources\views/components/application-mark.blade.php ENDPATH**/ ?>