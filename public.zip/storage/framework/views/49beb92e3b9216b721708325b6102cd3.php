<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Kampus\PKL\Astra Honda\project\gps-tracker-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>