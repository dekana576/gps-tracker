<?php echo e($slot); ?>

<?php /**PATH D:\Kampus\PKL\Astra Honda\project\gps-tracker-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>