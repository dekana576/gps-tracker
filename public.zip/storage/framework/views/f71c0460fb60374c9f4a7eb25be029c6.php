<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Unduh Laporan</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gradient-to-br from-blue-100 to-blue-200 font-sans antialiased min-h-screen">
        <div class="max-w-4xl mx-auto mt-16 px-6 lg:px-8">
            <!-- Card Container -->
            <div class="bg-white shadow-lg rounded-lg p-8">
                <!-- Header Section -->
                <div class="text-center mb-8">
                    <h1 class="text-3xl font-extrabold text-blue-600 mb-2">Unduh Laporan</h1>
                    <p class="text-gray-600">Pilih laporan yang ingin Anda unduh di bawah ini</p>
                </div>

                <!-- Buttons Section -->
                <div class="flex flex-col sm:flex-row sm:justify-center sm:space-x-6 gap-4">
                    <!-- User Report Button -->
                    <a href="<?php echo e(route('export.users')); ?>" 
                       class="bg-gradient-to-r from-green-400 to-green-500 hover:from-green-500 hover:to-green-600 text-white px-6 py-3 rounded-lg shadow-lg transform hover:scale-105 transition-transform text-sm font-medium">
                        Unduh Laporan User
                    </a>

                    <!-- History Report Button -->
                    <a href="<?php echo e(route('export.histories')); ?>" 
                       class="bg-gradient-to-r from-blue-400 to-blue-500 hover:from-blue-500 hover:to-blue-600 text-white px-6 py-3 rounded-lg shadow-lg transform hover:scale-105 transition-transform text-sm font-medium">
                        Unduh Laporan History
                    </a>
                </div>
            </div>

            <!-- Decorative Footer -->
            <div class="text-center mt-12">
                <p class="text-gray-500 text-sm">© 2024 Sistem Informasi Anda. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kampus\PKL\Astra Honda\project\gps-tracker-laravel\resources\views/reports/index.blade.php ENDPATH**/ ?>