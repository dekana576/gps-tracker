<a href="/">
    <img src="<?php echo e(asset('images/astra.png')); ?>" alt="logo" style="height: 80px;" class="w-auto">
</a>
<?php /**PATH D:\Kampus\PKL\Astra Honda\project\gps-tracker-laravel\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>