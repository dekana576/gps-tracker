<a href="/">
    <img src="{{ asset('images/astra.png')}}" alt="logo" style="height: 80px;" class="w-auto">
</a>
