<a href="/" style="display: flex; align-items: center; gap: 10px;">
    <img src="{{ asset('images/astra.png')}}" alt="logo astra" style="height: 40px;" class="w-auto">
    <img src="{{ asset('images/best.png')}}" alt="logo best" style="height: 40px;" class="w-auto">
</a>

